﻿using Microsoft.Data.SqlClient.DataClassification;

namespace MVC_Shop.Models.DTO
{
	public class ProductSubCategoryDTO
	{
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
